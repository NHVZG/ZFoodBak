CREATE TRIGGER t_afterdelete_on_sub
AFTER DELETE ON `order`
FOR EACH ROW
  begin   
      delete from `orderitem` where order_id=old.order_id;        
end;
