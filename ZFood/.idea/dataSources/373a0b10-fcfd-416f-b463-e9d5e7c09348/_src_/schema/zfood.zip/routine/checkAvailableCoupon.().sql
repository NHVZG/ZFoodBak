CREATE FUNCTION checkAvailableCoupon()
  RETURNS INT
  BEGIN
	#Routine body goes here...
        update couponitem set state=-1 WHERE   
           timestampdiff(DAY,CURDATE(),endTime)<0;
	RETURN 0;
END;
